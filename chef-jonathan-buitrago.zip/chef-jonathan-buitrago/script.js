// Variables globales
let isLoading = true;
let mobileMenuOpen = false;
let currentSection = 'hero';

// Elementos del DOM
const loader = document.getElementById('loader');
const scrollProgress = document.getElementById('scrollProgress');
const cursor = document.getElementById('cursor');
const cursorFollower = document.getElementById('cursorFollower');
const header = document.getElementById('header');
const mobileToggle = document.getElementById('mobileToggle');
const navMenu = document.getElementById('navMenu');
const navLinks = document.querySelectorAll('.nav-link');
const videoModal = document.getElementById('videoModal');
const closeModal = document.getElementById('closeModal');
const previewBtns = document.querySelectorAll('.preview-btn');
const contactForm = document.getElementById('contactForm');
const faqItems = document.querySelectorAll('.faq-item');

// Inicialización
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    // Simular carga
    setTimeout(() => {
        loader.classList.add('fade-out');
        isLoading = false;
        setTimeout(() => {
            loader.style.display = 'none';
            initializeAnimations();
        }, 600);
    }, 2000);

    setupEventListeners();
    setupSmoothScrolling();
    setupIntersectionObserver();
    setupFAQ();
    setupContactForm();
    setupCustomCursor();
}

function setupEventListeners() {
    // Scroll events
    window.addEventListener('scroll', handleScroll);
    window.addEventListener('resize', handleResize);

    // Navigation
    mobileToggle.addEventListener('click', toggleMobileMenu);
    navLinks.forEach(link => {
        link.addEventListener('click', handleNavigation);
    });

    // Modal events
    previewBtns.forEach(btn => {
        btn.addEventListener('click', openVideoModal);
    });
    closeModal.addEventListener('click', closeVideoModal);
    videoModal.addEventListener('click', (e) => {
        if (e.target === videoModal) closeVideoModal();
    });

    // Form validation
    const formInputs = contactForm.querySelectorAll('input, select, textarea');
    formInputs.forEach(input => {
        input.addEventListener('blur', validateInput);
        input.addEventListener('input', clearValidationError);
    });
}

function handleScroll() {
    if (isLoading) return;

    const scrolled = window.pageYOffset;
    const windowHeight = window.innerHeight;
    const documentHeight = document.documentElement.scrollHeight;

    // Update scroll progress
    const progress = (scrolled / (documentHeight - windowHeight)) * 100;
    scrollProgress.style.width = `${Math.min(progress, 100)}%`;

    // Header scroll effect
    header.classList.toggle('scrolled', scrolled > 100);

    // Update active navigation
    updateActiveSection();

    // Parallax effect for hero
    const hero = document.getElementById('hero');
    if (hero && scrolled < windowHeight) {
        hero.style.transform = `translateY(${scrolled * 0.5}px)`;
    }
}

function handleResize() {
    if (window.innerWidth > 768 && mobileMenuOpen) {
        closeMobileMenu();
    }
}

function toggleMobileMenu() {
    mobileMenuOpen = !mobileMenuOpen;
    mobileToggle.classList.toggle('active', mobileMenuOpen);
    navMenu.classList.toggle('show', mobileMenuOpen);
    document.body.style.overflow = mobileMenuOpen ? 'hidden' : '';
}

function closeMobileMenu() {
    mobileMenuOpen = false;
    mobileToggle.classList.remove('active');
    navMenu.classList.remove('show');
    document.body.style.overflow = '';
}

function handleNavigation(e) {
    e.preventDefault();
    const targetId = this.getAttribute('href');
    const targetElement = document.querySelector(targetId);

    if (targetElement) {
        const offsetTop = targetElement.offsetTop - 80;
        window.scrollTo({
            top: offsetTop,
            behavior: 'smooth'
        });

        if (mobileMenuOpen) closeMobileMenu();
        updateActiveNavigation(targetId);
    }
}

function updateActiveSection() {
    const sections = document.querySelectorAll('section[id]');
    const scrollPos = window.pageYOffset + 120;

    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.offsetHeight;
        const sectionId = section.getAttribute('id');

        if (scrollPos >= sectionTop && scrollPos < sectionTop + sectionHeight) {
            currentSection = sectionId;
            updateActiveNavigation(`#${sectionId}`);
        }
    });
}

function updateActiveNavigation(targetId) {
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === targetId) {
            link.classList.add('active');
        }
    });
}

function setupSmoothScrolling() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);

            if (targetElement) {
                const offsetTop = targetElement.offsetTop - 80;
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    });
}

function setupIntersectionObserver() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -10% 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry, index) => {
            if (entry.isIntersecting) {
                setTimeout(() => {
                    entry.target.classList.add('active');
                }, index * 100);
            }
        });
    }, observerOptions);

    // Observe fade-in elements
    document.querySelectorAll('.fade-in').forEach(el => {
        observer.observe(el);
    });
}

function initializeAnimations() {
    // Trigger hero animations
    const heroFeatures = document.querySelectorAll('.hero-feature');
    heroFeatures.forEach((feature, index) => {
        setTimeout(() => {
            feature.classList.add('active');
        }, 200 * index);
    });
}

function setupCustomCursor() {
    if (window.innerWidth > 1024) {
        document.addEventListener('mousemove', (e) => {
            cursor.style.left = e.clientX + 'px';
            cursor.style.top = e.clientY + 'px';

            setTimeout(() => {
                cursorFollower.style.left = e.clientX + 'px';
                cursorFollower.style.top = e.clientY + 'px';
            }, 100);
        });

        // Cursor hover effects
        const hoverElements = document.querySelectorAll('a, button, .course-card, .faq-question');
        hoverElements.forEach(el => {
            el.addEventListener('mouseenter', () => {
                cursor.style.transform = 'scale(1.5)';
                cursorFollower.style.transform = 'scale(2)';
            });

            el.addEventListener('mouseleave', () => {
                cursor.style.transform = 'scale(1)';
                cursorFollower.style.transform = 'scale(1)';
            });
        });
    }
}

function setupFAQ() {
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        const answer = item.querySelector('.faq-answer');

        question.addEventListener('click', () => {
            const isActive = question.classList.contains('active');

            // Close all other FAQ items
            faqItems.forEach(otherItem => {
                if (otherItem !== item) {
                    otherItem.querySelector('.faq-question').classList.remove('active');
                    otherItem.querySelector('.faq-answer').classList.remove('active');
                }
            });

            // Toggle current item
            if (!isActive) {
                question.classList.add('active');
                answer.classList.add('active');
            } else {
                question.classList.remove('active');
                answer.classList.remove('active');
            }
        });
    });
}

function setupContactForm() {
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();

        if (validateForm()) {
            submitForm();
        }
    });
}

function validateInput(e) {
    const input = e.target;
    const value = input.value.trim();
    const inputName = input.name;

    clearValidationError(input);

    if (input.hasAttribute('required') && !value) {
        showInputError(input, 'Este campo es obligatorio');
        return false;
    }

    switch (inputName) {
        case 'firstName':
        case 'lastName':
            if (value && value.length < 2) {
                showInputError(input, 'Debe tener al menos 2 caracteres');
                return false;
            }
            break;

        case 'email':
            if (value && !isValidEmail(value)) {
                showInputError(input, 'Ingresa un email válido');
                return false;
            }
            break;

        case 'phone':
            if (value && !isValidPhone(value)) {
                showInputError(input, 'Ingresa un teléfono válido');
                return false;
            }
            break;
    }

    return true;
}

function clearValidationError(input) {
    if (typeof input === 'object') {
        input.style.borderColor = '';
        const errorMsg = input.parentNode.querySelector('.error-message');
        if (errorMsg) errorMsg.remove();
    }
}

function showInputError(input, message) {
    input.style.borderColor = 'var(--error)';

    // Remove existing error message
    const existingError = input.parentNode.querySelector('.error-message');
    if (existingError) existingError.remove();

    // Add new error message
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.style.cssText = `
        color: var(--error);
        font-size: 0.9rem;
        margin-top: var(--space-xs);
        display: flex;
        align-items: center;
        gap: var(--space-xs);
    `;
    errorDiv.innerHTML = `<i class="fas fa-exclamation-circle"></i>${message}`;
    input.parentNode.appendChild(errorDiv);
}

function validateForm() {
    const requiredInputs = contactForm.querySelectorAll('[required]');
    let isValid = true;

    requiredInputs.forEach(input => {
        if (!validateInput({ target: input })) {
            isValid = false;
        }
    });

    return isValid;
}

function submitForm() {
    const submitBtn = contactForm.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;

    // Show loading state
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando...';
    submitBtn.disabled = true;

    // Simulate form submission
    setTimeout(() => {
        showNotification('¡Mensaje enviado exitosamente! Nos pondremos en contacto contigo en las próximas 24 horas.', 'success');
        contactForm.reset();

        // Reset button
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;

        // Clear any validation errors
        contactForm.querySelectorAll('input, select, textarea').forEach(clearValidationError);
    }, 2500);
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function isValidPhone(phone) {
    const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
    return phoneRegex.test(phone.replace(/[\s\-\(\)]/g, ''));
}

function openVideoModal(e) {
    const courseType = this.getAttribute('data-course');
    const modal = document.getElementById('videoModal');
    const modalTitle = modal.querySelector('.modal-title');

    // Update modal title based on course
    const courseTitles = {
        'chocolate': 'Adelanto: Chocolate Artesanal',
        'postres': 'Adelanto: Postres Temáticos',
        'decoracion': 'Adelanto: Técnicas de Decoración'
    };

    modalTitle.textContent = courseTitles[courseType] || 'Adelanto del Curso';

    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';

    setTimeout(() => {
        modal.classList.add('show');
    }, 10);
}

function closeVideoModal() {
    const modal = document.getElementById('videoModal');
    modal.classList.remove('show');
    document.body.style.overflow = '';

    setTimeout(() => {
        modal.style.display = 'none';
    }, 300);
}

function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => {
        notification.remove();
    });

    const notification = document.createElement('div');
    notification.className = `notification ${type}`;

    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };

    notification.innerHTML = `
        <div class="notification-content">
            <div class="notification-icon">
                <i class="fas ${icons[type] || icons.info}"></i>
            </div>
            <div class="notification-text">${message}</div>
            <button class="notification-close">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;

    document.body.appendChild(notification);

    // Show animation
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);

    // Close button functionality
    const closeBtn = notification.querySelector('.notification-close');
    closeBtn.addEventListener('click', () => {
        hideNotification(notification);
    });

    // Auto hide after 6 seconds
    setTimeout(() => {
        hideNotification(notification);
    }, 6000);
}

function hideNotification(notification) {
    notification.classList.remove('show');
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 300);
}

// Keyboard navigation
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        if (videoModal.classList.contains('show')) {
            closeVideoModal();
        }
        if (mobileMenuOpen) {
            closeMobileMenu();
        }
    }
});

// Enhanced button click effects
document.querySelectorAll('.btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
        const ripple = document.createElement('span');
        const rect = this.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = e.clientX - rect.left - size / 2;
        const y = e.clientY - rect.top - size / 2;

        ripple.style.cssText = `
            position: absolute;
            width: ${size}px;
            height: ${size}px;
            left: ${x}px;
            top: ${y}px;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            transform: scale(0);
            animation: ripple 0.6s ease-out;
            pointer-events: none;
        `;

        this.style.position = 'relative';
        this.style.overflow = 'hidden';
        this.appendChild(ripple);

        setTimeout(() => {
            ripple.remove();
        }, 600);
    });
});

// Add ripple animation
const style = document.createElement('style');
style.textContent = `
    @keyframes ripple {
        to {
            transform: scale(2);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Performance optimization: Throttle scroll events
function throttle(func, delay) {
    let timeoutId;
    let lastExecTime = 0;
    return function (...args) {
        const currentTime = Date.now();

        if (currentTime - lastExecTime > delay) {
            func.apply(this, args);
            lastExecTime = currentTime;
        } else {
            clearTimeout(timeoutId);
            timeoutId = setTimeout(() => {
                func.apply(this, args);
                lastExecTime = Date.now();
            }, delay - (currentTime - lastExecTime));
        }
    };
}

// Apply throttling to scroll handler
window.removeEventListener('scroll', handleScroll);
window.addEventListener('scroll', throttle(handleScroll, 16)); // ~60fps

// Lazy loading for images (if any are added later)
function setupLazyLoading() {
    const images = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.removeAttribute('data-src');
                imageObserver.unobserve(img);
            }
        });
    });

    images.forEach(img => imageObserver.observe(img));
}

// Call lazy loading setup
setupLazyLoading();

// Add focus management for accessibility
document.addEventListener('keydown', (e) => {
    if (e.key === 'Tab') {
        document.body.classList.add('keyboard-navigation');
    }
});

document.addEventListener('mousedown', () => {
    document.body.classList.remove('keyboard-navigation');
});

// Add focus styles for keyboard navigation
const keyboardStyle = document.createElement('style');
keyboardStyle.textContent = `
    .keyboard-navigation *:focus {
        outline: 2px solid var(--accent-solid);
        outline-offset: 2px;
    }
`;
document.head.appendChild(keyboardStyle);

console.log('🎂 Chef Jonathan Buitrago Website - Fully Loaded!');
console.log('✨ Enhanced with premium animations and interactions');
